# encoding: UTF-8
# frozen_string_literal: true
# This file is auto-generated from the current state of VCS.
# Instead of editing this file, please use bin/gendocs.

module Peatio
  class Application
    GIT_TAG =    '1.9.20'
    GIT_SHA =    'dbbef13'
    BUILD_DATE = 'Fri Feb 15 07:18:51 UTC 2019'
    VERSION =    GIT_TAG
  end
end
