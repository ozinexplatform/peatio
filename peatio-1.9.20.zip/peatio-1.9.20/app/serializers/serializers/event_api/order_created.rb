# encoding: UTF-8
# frozen_string_literal: true

module Serializers
  module EventAPI
    class OrderCreated < OrderEvent

    end
  end
end
