# encoding: UTF-8
# frozen_string_literal: true

module Private
  class SettingsController < BaseController
    def index

    end
  end
end

