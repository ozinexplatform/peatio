# encoding: UTF-8
# frozen_string_literal: true

module BlockchainService
  class Litecoin < Bitcoin

  end
end

