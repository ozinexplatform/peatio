## Coin currency
Add new currency record to `config/templates/seed/currencies.yml`
 
Change `id`, `code`, `symbol`, `precision`, `base_factor`, `api_client` and `json_rpc_endpoint` accordingly as per the currency requirements. 
