# encoding: UTF-8
# frozen_string_literal: true

module WalletClient
  class Dashd < Bitcoind

  end
end
